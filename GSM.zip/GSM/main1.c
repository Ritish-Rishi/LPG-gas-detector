#include <LPC214x.h> 
#define GAS (IO1PIN & (1<<24))
int main()
{
  call();
	while(1);
}